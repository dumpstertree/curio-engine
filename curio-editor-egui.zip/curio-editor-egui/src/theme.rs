//! Color/style constants for a custom OLED-inspired dark theme with pastel pink accents.

use eframe::egui::{self, Color32, CornerRadius, Stroke};

pub const BG_PRIMARY: Color32 = Color32::from_rgb(0x0B, 0x0B, 0x0C);
pub const BG_SECONDARY: Color32 = Color32::from_rgb(0x12, 0x12, 0x14);
pub const BG_TERTIARY: Color32 = Color32::from_rgb(0x1A, 0x1A, 0x1D);

pub const BG_HOVER: Color32 = Color32::from_rgb(0x24, 0x20, 0x26);
pub const BG_ACTIVE: Color32 = Color32::from_rgb(0x30, 0x2B, 0x34);

pub const BORDER: Color32 = Color32::from_rgb(0x2B, 0x2B, 0x30);
pub const BORDER_LIGHT: Color32 = Color32::from_rgb(0x40, 0x40, 0x46);

pub const TEXT_PRIMARY: Color32 = Color32::from_rgb(0xEE, 0xEE, 0xEF);
pub const TEXT_SECONDARY: Color32 = Color32::from_rgb(0xB8, 0xB8, 0xBE);
pub const TEXT_MUTED: Color32 = Color32::from_rgb(0x82, 0x82, 0x88);

pub const ACCENT: Color32 = Color32::from_rgb(0xF1, 0x9E, 0xF4);
pub const ACCENT_HOVER: Color32 = Color32::from_rgb(0xDB, 0x8E, 0xDE);
pub const ACCENT_ACTIVE: Color32 = Color32::from_rgb(0xC9, 0x7D, 0xCC);

pub const GREEN: Color32 = Color32::from_rgb(0x9D, 0xD9, 0xA6);
pub const BLUE: Color32 = ACCENT;
pub const ORANGE: Color32 = Color32::from_rgb(0xF3, 0xBE, 0x9A);

pub const PLAY: Color32 = Color32::from_rgb(0x6D, 0xC7, 0x85);
pub const PAUSE: Color32 = Color32::from_rgb(0xF3, 0xC4, 0x6A);
pub const RED: Color32 = Color32::from_rgb(0xF3, 0x9A, 0xA4);
pub const YELLOW: Color32 = Color32::from_rgb(0xF7, 0xDE, 0x8A);

pub fn apply(ctx: &egui::Context) {
    let mut visuals = egui::Visuals::dark();

    visuals.panel_fill = BG_PRIMARY;
    visuals.window_fill = BG_SECONDARY;
    visuals.extreme_bg_color = BG_TERTIARY;
    visuals.faint_bg_color = BG_HOVER;
    visuals.code_bg_color = BG_TERTIARY;

    visuals.hyperlink_color = ACCENT;
    visuals.override_text_color = Some(TEXT_PRIMARY);

    visuals.window_stroke = Stroke::new(1.0, BORDER);

    // Non-interactive
    visuals.widgets.noninteractive.bg_fill = BG_PRIMARY;
    visuals.widgets.noninteractive.weak_bg_fill = BG_PRIMARY;
    visuals.widgets.noninteractive.bg_stroke = Stroke::new(1.0, BORDER);
    visuals.widgets.noninteractive.fg_stroke = Stroke::new(1.0, TEXT_PRIMARY);

    // Default
    visuals.widgets.inactive.bg_fill = BG_TERTIARY;
    visuals.widgets.inactive.weak_bg_fill = BG_TERTIARY;
    visuals.widgets.inactive.bg_stroke = Stroke::new(1.0, BORDER);
    visuals.widgets.inactive.fg_stroke = Stroke::new(1.0, TEXT_SECONDARY);

    // Hover
    visuals.widgets.hovered.bg_fill = BG_HOVER;
    visuals.widgets.hovered.weak_bg_fill = BG_HOVER;
    visuals.widgets.hovered.bg_stroke = Stroke::new(1.0, ACCENT);
    visuals.widgets.hovered.fg_stroke = Stroke::new(1.0, TEXT_PRIMARY);

    // Pressed
    visuals.widgets.active.bg_fill = ACCENT_ACTIVE;
    visuals.widgets.active.weak_bg_fill = ACCENT_ACTIVE;
    visuals.widgets.active.bg_stroke = Stroke::new(1.0, ACCENT);
    visuals.widgets.active.fg_stroke = Stroke::new(1.0, BG_PRIMARY);

    // Toggled/Open
    visuals.widgets.open.bg_fill = ACCENT;
    visuals.widgets.open.weak_bg_fill = ACCENT;
    visuals.widgets.open.bg_stroke = Stroke::new(1.0, ACCENT);
    visuals.widgets.open.fg_stroke = Stroke::new(1.0, BG_PRIMARY);

    // Selection
    visuals.selection = egui::style::Selection { bg_fill: ACCENT, stroke: Stroke::new(1.0, BG_PRIMARY) };

    let radius = CornerRadius::same(2);

    visuals.widgets.noninteractive.corner_radius = radius;
    visuals.widgets.inactive.corner_radius = radius;
    visuals.widgets.hovered.corner_radius = radius;
    visuals.widgets.active.corner_radius = radius;
    visuals.widgets.open.corner_radius = radius;

    ctx.set_visuals(visuals);

    let mut style = (*ctx.style()).clone();

    style.spacing.item_spacing = egui::vec2(8.0, 8.0);
    style.spacing.button_padding = egui::vec2(10.0, 5.0);

    ctx.set_style(style);
}

use eframe::egui::{FontData, FontDefinitions, FontFamily};

pub fn install_fonts(ctx: &egui::Context) {
    let mut fonts = FontDefinitions::default();

    fonts
        .font_data
        .insert("Geist Pixel".into(), FontData::from_static(include_bytes!("../../assets/fonts/GeistMono.ttf")).into());

    fonts
        .families
        .get_mut(&FontFamily::Proportional)
        .unwrap()
        .insert(0, "Geist Pixel".into());

    ctx.set_fonts(fonts);
}
